
/*
Zupanijsko natjecanje 2004
Srednjoskolska skupina - II. podskupina
Zadatak NIZ - Programski jezik C
*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MAX_ZNAKOVA 500000 // za n <= 100000

int main(void)
{
  int i;
  int n;
  int index;
  char mali_broj[10],veliki_broj[MAX_ZNAKOVA];

  scanf("%d",&n);

  index = 0;
  for (i = 1;i <= n;++i)
  {
    itoa(i,mali_broj,10);
    strcpy(veliki_broj + index,mali_broj);
    index += strlen(mali_broj);
  }
  veliki_broj[index] = 0;

  printf("%d\n",strstr(veliki_broj,mali_broj) - veliki_broj + 1);

  return 0;
}
