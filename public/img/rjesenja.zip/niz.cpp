
/*
    Zupanijsko natjecanje 2004. / 2. podskupina
    2. zadatak - NIZ
    Rjesenje napisao Luka Kalinovcic (kalinov@mioc.hr)
*/

#include <cstdio>
#include <string>

using namespace std;

char buff[500000];
char broj[10];

int main( void ) {
  int i, k, n;
  char *p = buff;

  scanf( "%d", &n );
  for( i = 1; i <= n; p += k )
    sprintf( p, "%d%n", i++, &k );

  sprintf( broj, "%d", n );

  printf( "%d\n", string(buff).find( string(broj) )+1 );

  return 0;
}
