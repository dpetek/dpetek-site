
/*
Zupanijsko natjecanje 2004
Srednjoskolska skupina - II. podskupina
Zadatak GUSJENICA - Programski jezik C
*/

#include <stdio.h>

int broj_redaka,broj_stupaca;
int rjesenje;

void rijesi(void)
{
  int manji;

  manji = broj_redaka;
  if (broj_stupaca < manji)
    manji = broj_stupaca;

  rjesenje = 2 * (manji - 1);
  if (broj_redaka > broj_stupaca)
    ++rjesenje;
}

int main(void)
{
  scanf("%d%d",&broj_redaka,&broj_stupaca);
  rijesi();
  printf("%d\n",rjesenje);

  return 0;
}
