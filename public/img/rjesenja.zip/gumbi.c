
/*
Zupanijsko natjecanje 2004
Srednjoskolska skupina - II. podskupina
Zadatak GUMBI - Programski jezik C
*/

#include <stdio.h>
#include <string.h>

#define MAX_N 20

int bio[1 << MAX_N];
int q[1 << MAX_N];

int main (void)
{
	int i, j, k, n, m, cur, qs, qe;
	int maska[MAX_N + 1];
	int pocetno;

	scanf ("%d", &n);
	pocetno = 0;
	for (j = 0; j < n; ++j)
	{
		scanf ("%d", &k);
		pocetno |= k << j;
	}
	for (i = 0; i < n; ++i)
	{
		scanf ("%d", &m);
		cur = 0;
		for (j = 0; j < m; ++j)
		{
			scanf ("%d", &k);
			cur |= 1 << (k - 1);
		}
		maska[i] = cur;
	}

	memset (bio, -1, sizeof (bio));
	qs = qe = 0;
	bio[pocetno] = 0;
	q[qe++] = pocetno;
	for (;;)
	{
		if (qs >= qe)
		{
			printf ("Nema rjesenja.\n");
			break;
		}
		pocetno = q[qs++];
		if (pocetno == 4)
		{
			printf ("%d\n", bio[pocetno]);
			break;
		}
		for (i = 0; i < n; ++i)
			if (!((pocetno >> i) & 1))
			{
				j = (pocetno &~ maska[i]) | (1 << i);
				if (bio[j] == -1)
					bio[j] = bio[pocetno] + 1, q[qe++] = j;
			}
	}

	return 0;
}
