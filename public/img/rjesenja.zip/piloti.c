
/*
Zupanijsko natjecanje 2004
Srednjoskolska skupina - II. podskupina
Zadatak PILOTI - Programski jezik C
*/

#include <stdio.h>

#define MAXPILOTA	10000
#define MAXPLACA	100000

#define INFTY		(MAXPILOTA*MAXPLACA+1)
#define MIN(a,b)	((a)<(b) ? (a) : (b))

int brojPilota;
struct { int oficir, kapetan; } placa[MAXPILOTA];

void loadData ( void )
{
	int i;

	scanf ("%d", &brojPilota);
	for (i=0; i<brojPilota; i++)
		scanf ("%d%d", &placa[i].kapetan, &placa[i].oficir);
}

int solve ( void )
{
	int najmanjaSuma[MAXPILOTA/2], noviOptimum[MAXPILOTA/2];
	int iPilot, brojKapetana;

	// inicijalizacija polja:
	// prvi pilot nuzno je oficir jer je najmladji
	// trenutno ne mozemo imati niti jednog kapetana, pa ostatak polja stavljamo
	// na beskonacno
	najmanjaSuma[0]=placa[0].oficir;
	for (brojKapetana=1; brojKapetana<=brojPilota/2; brojKapetana++)
		najmanjaSuma[brojKapetana]=INFTY;

	// sada dodajemo jednog po jednog pilota i update-amo polje najmanjaSuma
	for (iPilot=1; iPilot<brojPilota; iPilot++)
	{
		for (brojKapetana=0; brojKapetana<=brojPilota/2; brojKapetana++)
		{
			int minKapetan, minOficir;
			noviOptimum[brojKapetana]=INFTY;

			// ako imamo i najmladjih pilota, medju njima je moguce imati
			// max. i/2 kapetana (inace nemamo dovoljno oficira sa kojima
			// bismo ih mogli spariti
			if ((iPilot+1)/2 < brojKapetana)
				continue;

			// slicno, ako imamo brojPilota/2+x pilota, medju njima mora
			// biti barem x kapetana jer u protivnom broj oficira prelazi
			// brojPilota/2, a treba ih biti tocno brojPilota/2
			if ((iPilot+1) > brojPilota/2 + brojKapetana)
				continue;

			// (gornja 2 uvjeta prirodno je staviti u granice nutarnje
			// for petlje, ovdje ih stavljamo van radi jasnoce)
			// iPilot+1 jer indexiramo od nule

			// 1. slucaj: i-ti pilot je j-ti po redu kapetan
			// tada je optimalna suma placa jednaka optimalnoj placi za (i-1)
			// pilota i (j-1) kapetana + placa i-tog pilota kao kapetana
			if (brojKapetana > 0 && najmanjaSuma[brojKapetana-1] != INFTY)
				minKapetan=najmanjaSuma[brojKapetana-1]+placa[iPilot].kapetan;
			else minKapetan=INFTY;

			// 2. slucaj: i-ti pilot je oficir, a imamo j kapetana
			// tada je optimalna suma placa jednaka optimalnoj placi za (i-1)
			// pilota i j kapetana + placa i-tog pilota kao oficira
			if (najmanjaSuma[brojKapetana] != INFTY)
				minOficir=najmanjaSuma[brojKapetana]+placa[iPilot].oficir;
			else
				minOficir=INFTY;

			// gledamo sto se vise isplati, da je i-ti pilot oficir ili kapetan:
			noviOptimum[brojKapetana]=MIN(minKapetan, minOficir);
		}

		// update najmanje sume:
		for (brojKapetana=0; brojKapetana<=brojPilota/2; brojKapetana++)
			najmanjaSuma[brojKapetana]=noviOptimum[brojKapetana];
	}

	// konacno rjesenje nalazi se u zadnjem elementu konacnog polja
	return najmanjaSuma[brojPilota/2];
}

void writeSolution (int rjesenje)
{
	printf ("%d\n", rjesenje);
}

int main ( void )
{
	loadData();
	writeSolution (solve());

	return 0;
}
