
/*
    Zupanijsko natjecanje 2004. / 2. podskupina
    1. zadatak - GUSJENICA
    Rjesenje napisao Luka Kalinovcic (kalinov@mioc.hr)
*/

#include <iostream>

using namespace std;

int main( void ) {
  int R, S;

  cin >> R >> S;

  cout << min( R*2 - 2, S*2 - 1 ) << endl;

  return 0;
}
