
/*
    Zupanijsko natjecanje 2004. / 2. podskupina
    3. zadatak - GUMBI
    Rjesenje napisao Luka Kalinovcic (kalinov@mioc.hr)
*/

#include <iostream>
#include <queue>
#include <vector>

using namespace std;

vector<int> maska;

int main( void ) {
  int n; cin >> n;
  int stanje = 0;

  for( int i = 0; i < n; ++i ) {
    int x; cin >> x;
    if( x ) stanje |= (1<<i);
  }
  for( int i = 0; i < n; ++i ) {
    maska.push_back( (1<<n)-1 );
    int m; cin >> m;
    for( int j = 0; j < m; ++j ) {
      int x; cin >> x; x--;
      maska.back() ^= (1<<x);
    }
  }

  vector<int> pritisaka( (1<<n), 1000000000 );
  pritisaka[stanje] = 0;

  queue<int> red;

  for( red.push( stanje ); !red.empty(); red.pop() ) {
    stanje = red.front();

    for( int gumb = 0; gumb < n; ++gumb ) {
      if( (stanje>>gumb)&1 ) continue;

      int novo_stanje = stanje & maska[gumb] | (1<<gumb);

      if( pritisaka[novo_stanje] <= pritisaka[stanje] + 1 ) continue;

      pritisaka[novo_stanje] = pritisaka[stanje] + 1;
      red.push( novo_stanje );
    }
  }

  cout << pritisaka[(1<<2)] << endl;

  return 0;
}
