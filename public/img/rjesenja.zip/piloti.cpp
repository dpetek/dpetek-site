
/*
    Zupanijsko natjecanje 2004. / 2. podskupina
    4. zadatak - PILOTI
    Rjesenje napisao Luka Kalinovcic (kalinov@mioc.hr)
*/

#include <iostream>
#include <queue>

using namespace std;
priority_queue< int > maxheap;

int main( void ) {
  int n, rez = 0, kap, zam;

  for( cin >> n; n; --n ) {
     cin >> kap >> zam;
     rez += kap;
     maxheap.push( kap-zam );
     if( n%2==0 ) { rez -= maxheap.top(); maxheap.pop(); }
  }

  cout << rez << endl;
  return 0;
}
